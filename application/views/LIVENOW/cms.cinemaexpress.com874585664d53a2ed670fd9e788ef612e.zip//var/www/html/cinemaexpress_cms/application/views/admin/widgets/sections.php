<!--<div class="navbar navbar-inverse navbar-fixed-top main-menu menu" role="navigation" style="margin-bottom:0px; position:relative; color:#fff;">
	
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand home_logo" rel="home" href="index.html"><i class="fa fa-home"></i></a>
	</div>
	
	<div class="collapse navbar-collapse">
		
		<ul class="nav navbar-nav menus">
        	<li class="active index_hide"><a href="index.html"><i class="fa fa-home"></i></a></li>
			<li><a href="#">Nation</a></li>
			<li><a href="#">States</a></li>
            <li><a href="city.html">Cities</a></li>
            <li><a href="#">Business</a></li>
            <li><a href="#">Sports</a></li>
            <li><a href="column1.html">Column</a></li>
            <li><a href="#">Entertainment</a></li>
            <li><a href="#">Magazines</a></li>
            <li><a href="#">E-Paper</a></li>
			<li><a href="#">All Actions &nbsp;<i class="fa fa-chevron-down"></i></a></li>
			
		</ul>
		
		
	</div>
</div>-->

	<div class="row">
        <div class="col-lg-12">
        <div class="ad728"> <img data-src="images/728x90.png"> </div>
      </div>
      </div>
    <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
        <div class="loc">
            <div class="location">
            <p> <span><img data-src="images/sun.jpg"></span>
            <span>72C</span> Chennai, Tamilnadu</p>
          </div>
            <p class="date">10.25AM, Monday - IST 16th March 2015</p>
          </div>
      </div>
        <div class="col-lg-6 col-md-6 col-sm-4 col-xs-12 logo_pad">
        <div class="main_logo"> <img data-src="images/main-logo.jpg"> </div>
      </div>
        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
        <div class="social_icons SocialCenter"> <a class="fb" href="#"><i class="fa fa-facebook"></i></a> <a class="google" href="#"><i class="fa fa-google-plus"></i></a> <a class="twit" href="#"><i class="fa fa-twitter"></i></a> <a class="rss" href="#"><i class="fa fa-rss"></i></a> <a class="search_hide" href="#"><i class="fa fa-search"></i></a> </div>
        <div class="search1">
            <form class="navbar-form formb" role="search">
            <div class="input-group">
                <input type="text" class="form-control tbox" placeholder="Search" name="srch-term" id="srch-term">
                <div class="input-group-btn">
                <button class="btn btn-default btn-bac" type="submit"><i class="fa fa-search"></i></button>
              </div>
              </div>
          </form>
          </div>
      </div>
      </div>
      </div>
      </div>
    <div class="row">
<div class="col-lg-12">
<div class="navbar navbar-inverse navbar-fixed-top main-menu menu" role="navigation" style="margin-bottom:10px; position:relative; color:#fff;">
	
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand home_logo" rel="home" href="index.html"><i class="fa fa-home"></i></a>
	</div>
	
	<div class="collapse navbar-collapse">
		
		<ul class="nav navbar-nav menus">
        	<!--  <li class="index_hide active"><a href="index.html"><i class="fa fa-home"></i></a></li>  -->
			<li><a class="MenuItem" href="#">Nation</a></li>
			<li class="StatesHover"><a class="MenuItem" href="#">States</a>
            <div class="MultiStatesContents MultiCitiesCont">
              <div class="MultiImageContent">
              <img data-src="images/astana.jpg">
              <a href="#">odio metus gravida ante, ut geg3e wegegew gegeg us id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/paris.jpg">
              <a href="#">gheherhrhr egeh egegwe odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/Arya.jpg">
              <a href="#">gege gghehgeeodio mrhrhetus gravida ante, ut pharetra mrhrassa metus id nunc. Duis shrcelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/italy.jpg">
              <a href="#">hrhrhrhrhodio metus gravrhrhida ante, ut pharetra massa rhrhmetus id nunc. Duis scelerrhrisque molestie</a>
              </div>
    
  </div>
            </li>
            <li class="CitiesHover"><a class="MenuItem" href="city.html">Cities</a>
            <div class="MultiCities" id="tabs3">
            <ul class="MultiCitiesList">
    <li><a href="#tabs-1">Bangaluru<i class="fa fa-chevron-right"></i></a></li>
    <li><a href="#tabs-2">Kochi<i class="fa fa-chevron-right"></i></a></li>
    <li><a href="#tabs-3">Chennai<i class="fa fa-chevron-right"></i></a></li>
    <li><a href="#tabs-4">Hydrabad<i class="fa fa-chevron-right"></i></a></li>
    <li><a href="#tabs-5">Coimbatore<i class="fa fa-chevron-right"></i></a></li>
            </ul>
            <div class="MultiCitiesContents">
              <div id="tabs-1" class="MultiCitiesCont">
              <div class="MultiImageContent">
              <img data-src="images/astana.jpg">
              <a href="#">odio metus gravida ante, ut geg3e wegegew gegeg us id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/paris.jpg">
              <a href="#">gheherhrhr egeh egegwe odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/Arya.jpg">
              <a href="#">gege gghehgeeodio mrhrhetus gravida ante, ut pharetra mrhrassa metus id nunc. Duis shrcelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/italy.jpg">
              <a href="#">hrhrhrhrhodio metus gravrhrhida ante, ut pharetra massa rhrhmetus id nunc. Duis scelerrhrisque molestie</a>
              </div>
    
  </div>
  <div id="tabs-2" class="MultiCitiesCont">
              <div class="MultiImageContent">
              <img data-src="images/eiffel.jpg">
              <a href="#">ohrhrhdio merhrtus gravida ante, urhrt pharehrtra massa metus id nunc. Duis hrhrhscelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/warsaw.jpg">
              <a href="#">4rh4rhodio metus grrravida ante, ut phjtrjtraretra masstjta metus id trjnunc. Duis sjtjtcelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/taj.jpg">
              <a href="#">odio metus trjgravida ante, ut pharetjtjtra massa metus id jtjtnunc. Duis sctjelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/tree.jpg">
              <a href="#">odio mettjtus gravida ante, ut pharetra mjtjtassa metus jtjtid nunc. Duis scejtjtrlerisqjtue molestie</a>
              </div>
    
  </div>
  <div id="tabs-3" class="MultiCitiesCont">
              <div class="MultiImageContent">
              <img data-src="images/loves.jpg">j
              <a href="#">jjtjtrjjodio mejttus gravida ante, jtjtut pharetra jtjmassa metus idjtt nunc. Duis sjtjtjcelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/cuty.jpg">
              <a href="#">tjtjtjtodio metus gravida ante, utjtt pharetra massa metus tjtjtjttid nunc. Duis sctjelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/ferrari.jpg">
              <a href="#">odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/heart.jpg">
              <a href="#">odio metjttus gravida ante, ut pjttharetra massa mettjjtjtus id nunc. Duis scelerisque molestie</a>
              </div>
    
  </div>
  
  <div id="tabs-4" class="MultiCitiesCont">
              <div class="MultiImageContent">
              <img data-src="images/paris.jpg">
              <a href="#">wfwrwrfwrodio metus gravida ante, utj pharetra massa metus ijtjtrd nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/italy.jpg">
              <a href="#">g3gg4odio metus gravirhrhrda ante, ut pharetrhtrhja massa metus id nunhthc. Duishjtr scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/astana.jpg">
              <a href="#">rhherodio metus gravhhtrida ante, ut pharetra massahtrh metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/money.jpg">
              <a href="#">odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
    
  </div>
  
  <div id="tabs-5" class="MultiCitiesCont">
              <div class="MultiImageContent">
              <img data-src="images/heart.jpg">
              <a href="#">odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/eiffelNight.jpg">
              <a href="#">odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/ferrari.jpg">
              <a href="#">odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
              <div class="MultiImageContent">
              <img data-src="images/lovebirds.jpg">
              <a href="#">odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie</a>
              </div>
    
  </div>
  
            </div>
            </div>
            </li>
            <li><a class="MenuItem" href="#">Business</a></li>
            <li><a class="MenuItem" href="#">Sports</a></li>
            <li><a class="MenuItem" href="column1.html">Column</a></li>
            <li><a class="MenuItem" href="#">Entertainment</a></li>
            <li><a class="MenuItem" href="#">Magazines</a></li>
            <li><a class="MenuItem" href="#">E-Paper</a></li>
			<li><a class="MenuItem AllSectionClick" href="#">All Actions &nbsp;<i class="fa fa-chevron-down"></i></a>
            <div class="MultiSection">
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">States</a>
            <a class="AllList" href="#">Tamilnadu</a>
            <a class="AllList" href="#">kerala</a>
            <a class="AllList" href="#">andhra pradhesh</a>
            <a class="AllList" href="#">karnatka</a>
            <a class="AllList" href="#">karnataka</a>
            <a class="AllList" href="#">odisha</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">cities</a>
            <a class="AllList" href="#">Bangaluru</a>
            <a class="AllList" href="#">Chennai</a>
            <a class="AllList" href="#">kochi</a>
            <a class="AllList" href="#">trivendram</a>
            <a class="AllList" href="#">hydrabad</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">columns</a>
            <a class="AllList" href="#">prabhu chawla</a>
            <a class="AllList" href="#">t j s george</a>
            <a class="AllList" href="#">ravi shankar</a>
            <a class="AllList" href="#">v sudharshan</a>
            <a class="AllList" href="#">Shamba dhar-kamath</a>
            <a class="AllList" href="#">shankar ayyar</a>
            <a class="AllList" href="#">soli j sorabjee</a>
            <a class="AllList" href="#">s gurumurthy</a>
            <a class="AllList" href="#">kamlendra kanvar</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">Entertainment</a>
            <a class="AllList" href="#">tamil</a>
            <a class="AllList" href="#">telugu</a>
            <a class="AllList" href="#">Malayalam</a>
            <a class="AllList" href="#">hindi</a>
            <a class="AllList" href="#">English</a>
            <a class="AllList" href="#">review</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">Sports</a>
            <a class="AllList" href="#">Cricket</a>
            <a class="AllList" href="#">football</a>
            <a class="AllList" href="#">vollyball</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">magazine</a>
            <a class="AllList" href="#">voices</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">photos</a>
            <a class="AllTopic" href="#">videos</a>
            <a class="AllTopic" href="#">nation</a>
            <a class="AllTopic" href="#">world</a>
            <a class="AllTopic" href="#">business</a>
            </div>
            <div class="MultiSectionList">
            <a class="AllTopic" href="#">ipl-2016</a>
            <a class="AllTopic" href="#">ask prabhu</a>
            <a class="AllTopic" href="#">tech</a>
            <a class="AllTopic" href="#">education</a>
            </div>
           
            </div>
            
            
            </li>
			
		</ul>
		
		
	</div>
</div>
</div>
</div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="line">
            <h3 class="breaking">BREAKING NEWS</h3>
            <p>Pakistan Flags Waved, BJP Flag Burnt During Separatist Rally in Kashmir</p>
          </div>
      </div>
      </div>