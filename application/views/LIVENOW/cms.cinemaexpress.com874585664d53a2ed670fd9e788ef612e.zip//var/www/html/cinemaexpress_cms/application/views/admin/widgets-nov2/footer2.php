<?php 

$widget_bg_color 		= $content['widget_bg_color'];
$widget_custom_title 	= $content['widget_title'];
$widget_instance_id 	= $content['widget_values']['data-widgetinstanceid'];
$main_sction_id 		= "";
$page_type 				= 'section';
?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footer2bac">
  <div class="footer2">
    <p>Copyrights New Indian Express. 2016</p>
    <p> <a class="AllTopic" href="<?php echo base_url(); ?>"><?php echo "Home"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."nation"; ?>"><?php echo "Nation"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."world"; ?>"><?php echo "World"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."cities"; ?>"><?php echo "Cities"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."business"; ?>"><?php echo "Business"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."columns"; ?>"><?php echo "Columns"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."entertainment"; ?>"><?php echo "Entertainment"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."sport"; ?>"><?php echo "Sport"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."magazine"; ?>"><?php echo "Magazine"; ?> </a></p>
    <p> <a class="AllTopic" href="<?php echo base_url()."thesundaystandard"; ?>"><?php echo "The Sunday Standard"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."contact-us"; ?>"><?php echo "Contact Us"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."about-us"; ?>"><?php echo "About Us"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."privacy-policy"; ?>"><?php echo "Privacy Policy"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."topic"; ?>"><?php echo "Search"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."terms-of-use"; ?>"><?php echo "Terms of Use"; ?> | </a> <a class="AllTopic" href="<?php echo base_url()."advertise-with-us"; ?>"><?php echo "Advertise With Us"; ?> </a></p>
  </div>
</div>
