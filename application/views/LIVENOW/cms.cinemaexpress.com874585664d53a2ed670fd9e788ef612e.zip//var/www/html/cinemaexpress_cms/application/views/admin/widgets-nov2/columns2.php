<div class="most blog">
<h5 class="br_bottom topic">Columns</h5>
<div class="most1 br_bottom">
<img src="<?php echo $image_path_inwd; ?>images/home/blog1.jpg">
<p>To celebrate a year of the Narendra Modi government</p>
<div class="blog_social">
<a class="blog_read" href="#">Read More</a>
<div class="social_icons">
<a class="fb" href="#"><i class="fa fa-facebook"></i></a>
<a class="google" href="#"><i class="fa fa-google-plus"></i></a>
<a class="twit" href="#"><i class="fa fa-twitter"></i></a>
<a class="rss" href="#"><i class="fa fa-rss"></i></a>
<a class="search_hide" href="#"><i class="fa fa-search"></i></a>
</div>
</div>

</div>
<div class="most1 br_bottom">
<img src="<?php echo $image_path_inwd; ?>images/home/blog12.jpg">
<p>To celebrate a year of the Narendra Modi government</p>
<div class="blog_social">
<a class="blog_read" href="#">Read More</a>
<div class="social_icons">
<a class="fb" href="#"><i class="fa fa-facebook"></i></a>
<a class="google" href="#"><i class="fa fa-google-plus"></i></a>
<a class="twit" href="#"><i class="fa fa-twitter"></i></a>
<a class="rss" href="#"><i class="fa fa-rss"></i></a>
<a class="search_hide" href="#"><i class="fa fa-search"></i></a>
</div>
</div>
</div>
<div class="most1 br_bottom">
<img src="<?php echo $image_path_inwd; ?>images/home/blog13.jpg">
<p>To celebrate a year of the Narendra Modi government</p>
<div class="blog_social">
<a class="blog_read" href="#">Read More</a>
<div class="social_icons">
<a class="fb" href="#"><i class="fa fa-facebook"></i></a>
<a class="google" href="#"><i class="fa fa-google-plus"></i></a>
<a class="twit" href="#"><i class="fa fa-twitter"></i></a>
<a class="rss" href="#"><i class="fa fa-rss"></i></a>
<a class="search_hide" href="#"><i class="fa fa-search"></i></a>
</div>
</div>
</div>
<div class="most1">
<img src="<?php echo $image_path_inwd; ?>images/home/blog4.jpg">
<p>To celebrate a year of the Narendra Modi government</p>
<div class="blog_social">
<a class="blog_read" href="#">Read More</a>
<div class="social_icons">
<a class="fb" href="#"><i class="fa fa-facebook"></i></a>
<a class="google" href="#"><i class="fa fa-google-plus"></i></a>
<a class="twit" href="#"><i class="fa fa-twitter"></i></a>
<a class="rss" href="#"><i class="fa fa-rss"></i></a>
<a class="search_hide" href="#"><i class="fa fa-search"></i></a>
</div>
</div>
</div>
<span class="arrow_right"><a href="#" class="landing-arrow">arrow</a></span>
</div>