<section class="section-footer">
<footer class="FooterContainer container">
	<?php echo $view_templ; ?>
</footer>
</section>