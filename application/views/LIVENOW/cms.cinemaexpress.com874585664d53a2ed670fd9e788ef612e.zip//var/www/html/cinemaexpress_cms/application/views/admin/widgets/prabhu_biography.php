<?php
$url_segment1 = $this->uri->segment(1); 
$url_segment2 = $this->uri->segment(2); 
?>
<div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="AskPrabhu">
		<img src="<?php print base_url('images/static_img/banner.jpg') ?>" class="img-thumbnail img-responsive">
      </div>
</div>
</div>