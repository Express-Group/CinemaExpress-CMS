<div class="row margin-top-10">
  <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
    <div class="loc">
      <div class="location"> <img data-src="<?php echo base_url(); ?>prabhu/images/sun.jpg" style="width:auto;">
        <p><span>72C</span> Chennai, Tamilnadu</p>
      </div>
      <p class="date">10.25AM, Monday - IST 16th March 2015</p>
    </div>
  </div>
  <div class="col-lg-6 col-md-6 col-sm-4 col-xs-12 logo_pad">
    <div class="main_logo"> <img data-src="<?php echo base_url(); ?>prabhu/images/main-logo.jpg"> </div>
  </div>
  <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
    <div class="social_icons"> <a class="fb" href="#"><i class="fa fa-facebook"></i></a> <a class="google" href="#"><i class="fa fa-google-plus"></i></a> <a class="twit" href="#"><i class="fa fa-twitter"></i></a> <a class="rss" href="#"><i class="fa fa-rss"></i></a> <a class="search_hide" href="#"><i class="fa fa-search"></i></a> </div>
    <div class="search1">
      <form class="navbar-form formb" role="search">
        <div class="input-group">
          <input type="text" class="form-control tbox" placeholder="Search" name="srch-term" id="srch-term">
          <div class="input-group-btn">
            <button class="btn btn-default btn-bac" type="submit"><i class="fa fa-search"></i></button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
