<div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
           <h4 class="form-title">Contact Us</h4>
          <img src="<?php echo image_url;?>images/FrontEnd/images/TNIE-office.png" title="TNIE-office">
           <div class="contact-section">
           <div class="contact-address">
           <h4>Sudhir Srinivasan</h4>
           <p>Entertainment Editor,</p>
           <p>Express Network Private Limited,</p>
           <p>Express Gardens,</p>
           <p>2nd Main Road,</p>
           <p>Ambattur Industrial Estate,</p>
           <p>Chennai - 600 058,</p>
           <p>India.</p>
           <p><span>Phone:</span>  +91-44-2345 7601 - 07</p>
           <p><span>Fax:</span> +91-44-2345 7619</p>
           <p><span>E-mail:</span>  sudhirs@newindianexpress.com /   writetous@newindianexpress.com</p>
           </div>
            </div>
             <div class="contact-section">
           <div class="contact-address">
           <h4>To advertise on the site write to:</h4>
           <h4>Mrs. Jayshree,</h4>
           <p>Asst General Manager (Marketing),</p>
           <p>Express Network Private Limited,</p>
           <p><span>e-mail:</span> jayshree@newindianexpress.com,</p>
           <p><span>Mobile:</span>   +91 95000 52772,</p>
           <p><span>Phone:</span>   +91-44-2345 7601 – 07,</p>
           <p><span>Fax:</span>       +91-44-2345 7619.</p>
           </div>
           </div>
         </div>
        </div>