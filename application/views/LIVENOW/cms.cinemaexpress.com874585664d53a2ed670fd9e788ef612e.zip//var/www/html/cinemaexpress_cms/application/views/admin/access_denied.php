
<style>
.MainTitle{
	 font-size: 40px;
    text-align: center;
	height:500px;
	}
.MainTitle p:first-child{
	padding-top:300px;
	}
.MainTitle p{
	line-height:50px;
	font-family:Arial, Helvetica, sans-serif;
	}
</style>

<div class="MainTitle">
<p>Sorry, You don't have the permission the access </p>
<p>  to <?php echo $module; ?></p>
</div>