<section class="section-content">
<div class="container SectionContainer">
	<?php echo $view_templ; ?>
    </div>
</section>