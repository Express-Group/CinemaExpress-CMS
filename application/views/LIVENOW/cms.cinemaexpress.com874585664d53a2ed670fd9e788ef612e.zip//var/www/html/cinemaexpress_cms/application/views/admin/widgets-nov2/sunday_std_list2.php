
<div class="row">  // Row started 
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="SundaySecond">
<div class="WidthFloat_L">
<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 SundaySecondSplit">
<a href="#"><img data-src="file:///D|/Gufolder/images/resort77.jpg" class="ImageBorder"></a>
<h4 class="subtopic">
<a href="#">B-Town Glitters at Cannes</a>
</h4>
<p class="margin-bottom-0">Aishwarya Rai's first appearance in a teal gown was average. Then she messed it up badly in a wine-coloured Oscar de la Renta body-hugging</p>

</div>


<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 SundaySecondSplit">
<a href="#"><img data-src="file:///D|/Gufolder/images/resort77.jpg" class="ImageBorder"></a>
<h4 class="subtopic">
<a href="#">B-Town Glitters at Cannes</a>
</h4>
<p class="margin-bottom-0">Aishwarya Rai's first appearance in a teal gown was average. Then she messed it up badly in a wine-coloured Oscar de la Renta body-hugging</p>

</div>

<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 SundaySecondSplit">
<a href="#"><img data-src="file:///D|/Gufolder/images/resort77.jpg" class="ImageBorder"></a>
<h4 class="subtopic">
<a href="#">B-Town Glitters at Cannes</a>
</h4>
<p class="margin-bottom-0">Aishwarya Rai's first appearance in a teal gown was average. Then she messed it up badly in a wine-coloured Oscar de la Renta body-hugging</p>

</div> // Sunday SecondSplit End 

</div>  //WidthFlaot_L End 


</div> // Row started 
</div> // Row started 
</div> // Row started 