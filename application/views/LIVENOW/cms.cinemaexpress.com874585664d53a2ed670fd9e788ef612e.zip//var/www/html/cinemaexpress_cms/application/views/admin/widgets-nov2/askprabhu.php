<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="ask_prabu">
			<h4><a href="<?php echo base_url(); ?>prabhu-chawla/ask-prabhu">Ask Prabhu</a></h4>
			<table>
				<tbody>
					<tr>
						<td><img src="<?php echo image_url. imagelibrary_image_path?>prabhu_chawla.png" data-src="<?php echo image_url. imagelibrary_image_path?>prabhu_chawla.png" title="Prabhu Chawla" alt="Prabhu Chawla"></td>
						<td><a href="<?php echo base_url();?>prabhu-chawla/ask-prabhu" class="editorial"><strong>Prabhu Chawla</strong><br>
							<span>Editorial Director</span>
							<p>your tomorrow  depends on the question you ask today</p>
							</a></td>
					</tr>
				</tbody>
			</table>
			<div class="ask_column">
				<h5><a href="<?php echo base_url();?>prabhu-chawla/column" class="editorial"> <strong>Column:</strong> Power And Politics</a></h5>
			</div>
		</div>
	</div>
</div>
