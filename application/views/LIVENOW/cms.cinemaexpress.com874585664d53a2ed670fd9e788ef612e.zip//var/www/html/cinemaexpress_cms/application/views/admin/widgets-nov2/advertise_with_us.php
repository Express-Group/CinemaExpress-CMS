<div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
           <h4 class="form-title">Advertise With Us</h4>
        <div class="privacy-policy">
        <p>The New Indian Express Group is one of South India's leading media conglomerates, publishing newspapers in English, Tamil and Kannada and magazines in Tamil and Malayalam, across South India and Orissa.</p>
        <p>We are also one of the largest news providers on the internet through our news websites. We hosts 6 websites in 4 different languages - English, Tamil, Kannada and Malayalam.</p>
        <h4 class="statich4">Group Websites:</h4>
         <ul>
         <li><a href="#"><i class="fa fa-angle-right"></i> NEW INDIAN EXPRESS</a></li>
         <li><a href="#"><i class="fa fa-angle-right"></i> DINAMANI</a></li>
         <li><a href="#"><i class="fa fa-angle-right"></i> KANNADA PRABHA</a></li>
         <li><a href="#"><i class="fa fa-angle-right"></i> MALAYALAM VAARIKA</a></li>
         <li><a href="#"><i class="fa fa-angle-right"></i> SAKHI</a></li>
         <li><a href="#"><i class="fa fa-angle-right"></i> CINEMA EXPRESS</a></li>
         </ul>
         <h4 class="statich4">For advertising in our newspapers:</h4>
          <p> The New Indian Express, Dinamani (tamil) and KannadaPrabha (kannada), Please contact the following –</p>
          <h4 class="statich4">SMD Heads</h4>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">CORPORATE</li>
          <li>SATHYANARAYANAN</li>
          <li>9244317292</li>
          <li><a href="#">sathyanarayana@newindianexpress.com</a></li>
          </ul>
            </div>
            <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">CHENNAI</li>
          <li>MADAN MOHAN</li>
          <li>9282438111</li>
          <li><a href="#">kmadanmohan@newindianexpress.com</a></li>
          </ul>
            </div>
            <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">MADURAI</li>
          <li>DILIP KUMAR</li>
          <li>9244317035</li>
          <li><a href="#">dilip@newindianexpress.com</a></li>
          </ul>
            </div>
            <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">COIMBATORE</li>
          <li>PRATHAP</li>
          <li>9244317043</li>
          <li><a href="#">m_pratap@newindianexpress.com</a></li>
          </ul>
            </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">TRICHY</li>
          <li>MEENAKSHISUNDAR</li>
          <li>9244317193</li>
          <li><a href="#">c_meenakshi@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">TIRUNELVELI</li>
          <li>RAGHU SUBRAMANIAM</li>
          <li>9840304050</li>
          <li><a href="#">raghu@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">VELLORE</li>
          <li>MADAN MOHAN</li>
          <li>9282438111</li>
          <li><a href="#">kmadanmohan@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">VILLUPURAM</li>
          <li>SURESHKUMAR</li>
          <li>9578181444</li>
          <li><a href="#">suresh.kumar@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">DHARMAPURI</li>
          <li>BALASUBRAMANIAN</li>
          <li>9566899666</li>
          <li><a href="#">r_balasubramanian@newindianexpress.com</a></li>
          </ul>
          </div>
         <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">BANGALORE</li>
          <li>GURURAJ</li>
          <li>9243481242</li>
           <li><a href="#">gururajnr@newindianexpress.com</a></li>
            </ul>
            </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">BELGAUM</li>
          <li>SATISH JOSHI</li>
          <li>9483490965</li>
           <li><a href="#">satishjoshi@newindianexpress.com</a></li>
          </ul>
          </div>
           <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">SHIMOGA</li>
          <li>L N MURTHY</li>
          <li>9844060600</li>
         <li><a href="#">lnmurthy@newindianexpress.com</a></li>
         </ul>
         </div>
           <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">MANGALORE</li>
          <li>DHANURAJ</li>
          <li>9244351389</li>
           <li><a href="#">dhanuraj@newindianexpress.com</a></li>
         </ul>
         </div>
         <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">HUBLI</li>
          <li>SATISH JOSHI</li>
          <li>9483490965</li>
          <li><a href="#">satishjoshi@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">KOCHI</li>
          <li>CHANDRASEKHARAN</li>
          <li>9947053666</li>
          <li><a href="#">chandrasekharan@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">TRIVANDRUM</li>
          <li>SURESH KUMAR</li>
          <li>9249601088</li>
           <li><a href="#">g_sureshkumar@newindianexpress.com</a></li>
            </ul>
            </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">KOZHIKODE</li>
          <li>VINEETH KUMAR</li>
          <li>9497207528</li>
           <li><a href="#">vineeth@newindianexpress.com</a></li>
          </ul>
          </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">HYDERABAD</li>
          <li>RAMAKRISHNA RAO</li>
          <li>9246391021</li>
           <li><a href="#">b_ramakrishna@newindianexpress.com</a></li>
        </ul>
        </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">VIJAYAWADA</li>
          <li>RAGHUBABU</li>
          <li>9246391165</li>
           <li><a href="#">pt_raghu@newindianexpress.com</a></li>
       </ul>
       </div>
         <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">VISAKHAPATNAM</li>
          <li>KANAKARAJU</li>
          <li>9505991199</li>
           <li><a href="#">kanakarajub@newindianexpress.com</a></li>
          </ul>
          </div>
         <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">TIRUPATI</li>
          <li>SRINIVASA RAO</li>
          <li>9052668866</li>
           <li><a href="#">ksrao@newindianexpress.com</a></li>
         </ul>
         </div>
         <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">BHUBANESWAR</li>
          <li>PRASANNA PANDA</li>
          <li>9238003503</li>
           <li><a href="#">prasanna@newindianexpress.com</a></li>
          </ul>
          </div>
        <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">MUMBAI</li>
          <li>AMITABH BISHNOI</li>
          <li>9769521222</li>
           <li><a href="#">bishnoi.amitabh@newindianexpress.com</a></li>
      </ul>
      </div>
         <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">NEW DELHI</li>
          <li>SUBHASH PANDEY</li>
          <li>9899445105</li>
           <li><a href="#">subhash.pandey@newindianexpress.com</a></li>
         </ul>
         </div>
          <div class="Advertise-sec">
          <ul class="table-cover">
          <li class="static-bold">KOLKOTA</li>
          <li>ALOKA KAPUR</li>
          <li>9831048632</li>
           <li><a href="#">alokakapur@newindianexpress.com</a></li>
          </ul>
          </div>
        
             <h4 class="statich4">For online advertising, Please contact</h4> 
             <h4>Mrs. Jayshree,</h4>
             <ul class="online-ad">
        <li>Sr Manager - Online Marketing,</li>
        <li>Express Network Private Limited</li>
        <li>e-mail: <a href="#">jayshree@newindianexpress.com</a></li>
        <li>Mobile:   +91 95000 52772</li>
        <li>Phone:   +91-44-2345 7601 – 07</li>
        <li>Fax:       +91-44-2345 7619</li>
</ul>
        <div id="no-more-tables">
            <table class="col-md-12 table-bordered table-striped table-condensed cf">
        		<thead class="cf">
        			<tr>
        				<th>Types</th>
        				<th>Size</th>
        				<th class="numeric">Specification</th>
        				<th class="numeric">Sample/Demo</th>
        				
        			</tr>
        		</thead>
        		<tbody>
        			<tr>
        				<td data-title="Types ">Banner Ads</td>
        				<td class="mob-td"></td>
        				<td class="mob-td"></td>
        				<td class="mob-td"></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Leader Board</td>
        				<td data-title="Size ">728x90</td>
        				<td data-title="Specification" class="numeric">Jpeg / Flash banners max file size:< 30kb Runtime: not to exceed 7 seconds Landing page URL should be provided separately.</td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Medium Rectangle</td>
        				<td data-title="Size ">300x250</td>
        				<td class="mob-td"></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">SkyScraper</td>
        				<td data-title="Size ">120x600</td>
        				<td class="mob-td"></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">WideSky</td>
        				<td data-title="Size ">160x600</td>
        				<td class="mob-td"></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Tower</td>
        				<td data-title="Size ">120x240</td>
        				<td class="mob-td"></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Button1</td>
        				<td data-title="Size ">120x90</td>
        				<td class="mob-td"></td>
        			<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Button2</td>
        				<td data-title="Size ">120x60</td>
        				<td class="mob-td"></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
                    <tr>
        				<td data-title="Types  ">Text Links</td>
        				<td class="mob-td"></td>
        				<td data-title="Specification" class="numeric">Text as it needs to appear on the site Landing pageURL</td>
        				<td class="mob-td"></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">E Mailer</td>
        				<td class="mob-td"></td>
        				<td class="mob-td"></td>
        				<td class="mob-td"></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Rich Media Ads</td>
        				<td class="mob-td"></td>
        				<td class="mob-td"></td>
        				<td class="mob-td"></td>
        			</tr>
        			<tr>
        				<td data-title="Types  ">Slider</td>
        				<td class="mob-td"></td>
        				<td data-title="Specification" class="numeric"><a href="#">Click here to View Specification</a></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
                    <tr>
        				<td data-title="Types  ">Expandables</td>
        				<td class="mob-td"></td>
        				<td data-title="Specification" class="numeric"><a href="#">Click here to View Specification</a></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
                    <tr>
        				<td data-title="Types  ">Intromercials</td>
        				<td class="mob-td"></td>
        				<td data-title="Specification" class="numeric"><a href="#">Click here to View Specification</a></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
                    <tr>
        				<td data-title="Types  ">Page Peel</td>
        				<td class="mob-td"></td>
        				<td data-title="Specification" class="numeric"><a href="#">Click here to View Specification</a></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
                    <tr>
        				<td data-title="Types  ">Page Pusher</td>
        				<td class="mob-td"></td>
        				<td data-title="Specification" class="numeric"><a href="#">Click here to View Specification</a></td>
        				<td data-title="Sample/Demo" class="numeric view-sample"><a href="#">View Sample</a></td>
        			</tr>
        		</tbody>
        	</table>
        </div>
<p>Through our websites, we reach out to all four South Indian communities across the globe. We drive very high NRI as well as domestic traffic purely on our news strength. Our ad inventory helps you reach the right profiles and generate higher returns for your investment. We offer, to our advertisers, various innovative advertising options to reach to the target audience.</p>
<h4 class="statich4">Ad Specifications & Sizes</h4>
<h4 class="statich4">Banner Ads</h4>
<p><strong>Banner sizes</strong> : 468x60, 728x90, 160x600, 120x600, 300x250, 120x240</p>
<h4 class="statich4">Rich Media Ads</h4>
<p>Anyone serving ads on the Internet should take a look at Rich Media. Rich Media ads show a 38 percent higher click-through rate than normal banner ads.</p>
<p>Rich media ads are well on the way to dominating online advertising. Broadband connectivity is the norm, Internet users are overlooking banner ads, and Rich Media Ads are becoming the best option for advertisers.</p>
<h4 class="statich4">How it Works?</h4>
<p>The Rich Media experience, video streamed to the user, is similar to watching a traditional television commercial - with the added benefit of being able to click through to the advertiser's website, or to skip the ad and go to the main website.</p>
<h4 class="statich4">Types of Ads</h4>
<ul>
<li><i class="fa fa-angle-right"></i> Intromercial/ Full Page/ Site Capture </li>
<li> <i class="fa fa-angle-right"></i> Expandables/ Shoshkele </li>
<li><i class="fa fa-angle-right"></i> Sliders</li>
</ul>
<h4 class="statich4">Intromercials Ad Format</h4>
<p>The Intromercial ad format is a simple, repeatable format that sets a good standard for advertisers.What's attractive to advertisers is that intromercials reportedly deliver 5 to 10 times better response rates than banner ads (partially because intromercials allow a plethora of rich media executions).</p>
<p>A Full page Intromercial takes over the entire screen and usually appears either when the user first enters the website or is checking one of the internal pages. Since this blocks the actual web page it usually last for few seconds so as to not irritate the web visitor. Most Intromercials feature a "continue" and a "about the ad" buttons that allow the visitor to skip the ad or know more about the advertiser. They usually have a frequency cap of 1, so the user only has to watch it on the first visit of the day.</p>
<p>By default, Intromercials just play for few seconds before getting redirected to the requested publisher page.</p>
<h4 class="statich4">Intromercials with Leave-Behind</h4>
<p>An additional option is available where by the Intromercial leaves behind a small 120 x 90 pop-up at the top-right corner of the screen. This popup has a Close and Replay buttons. On clicking the close button, the small leave behind will disappear. On clicking the replay button, the entire Intromercial will play again. The Leave-behind pop-ups are shown only for the first four page request by the particular user.</p>
<h4 class="statich4">Standard Specifications</h4>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">With Leave Behind</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any Size</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Image, Flash(.swf only ), 3rd party code or any HTML code.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: lie Intromercial may include a header wili site logo, about liis ad link, and/or a "skip" link. liis ad is frequency capped to 1 and has a play time.</li>
<li></li>
</ul>
</div>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Wiliout Leave Behind</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any Siz</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Image, Flash(.swf only ), 3rd party code or any HTML code.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: lie Intromercial may include a header wili site logo, about liis ad link, and/or a "skip" link. liis ad is frequency capped to 1 and has a play time.</li>
<li></li>
</ul>
</div>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Replay</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any IAB size or custom size.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Flash (.swf )</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: The Intromercial may include a header with site logo.There is a replay button that redirects the user to view the full page ad again.</li>
<li></li>
</ul>
</div>

<h4 class="statich4">Expandable Ad Format</h4>
<p>The expandable panel runs in current ad positions, and can contain anything one would normally put on a web page (including additional information, dynamic data, video streaming, data collection, interactive games, and more).</p>
<h4 class="statich4">Standard Specifications</h4>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Mouse Roll-Over</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any IAB size or custom size.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Flash (.swf )</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: For liis setup we require 2 flash files. lie close button functionality should be added in lie flash file.</li>
<li></li>
</ul>
</div>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Replay – Close</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any IAB size or custom size.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Flash (.swf )</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: For liis setup we require 2 flash files. lie replay and close button functionality should be added in lie flash file.</li>
<li></li>
</ul>
</div>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Overlay / Floater</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any IAB size or custom size.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Flash (.swf )</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: Close button required.</li>
<li></li>
</ul>
</div>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Page Peel</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any IAB size or custom size.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Flash (.swf )</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: Close, replay buttons required.</li>
<li></li>
</ul>
</div>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="static-bold">Page Pusher</li>
<li></li>
</ul>
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>Any IAB size or custom size.</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Flash (.swf )</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
<ul class="table-cover">
<li>NOTE: Close, replay buttons required.</li>
<li></li>
</ul>
</div>
<h4 class="statich4">Sliders</h4>
<p>The banner slides on to the screen from the Right hand side corners, commanding instant attention from the viewers. The ad sizes could be 160x600,120x600,120x240 etc. It has a close and replay buttons. </p>
<ul class="list-full">
<li><i class="fa fa-angle-right"></i> Jpeg / Flash banners </li>
<li><i class="fa fa-angle-right"></i> max file size:< 30kb </li>
<li><i class="fa fa-angle-right"></i> Runtime: not to exceed 7 seconds </li>
<li><i class="fa fa-angle-right"></i> Landing page URL should be provided separately.</li>
</ul>
<h4 class="statich4">Ads on Photos</h4>
<ul class="list-full">
 <li><i class="fa fa-angle-right"></i> Ad appears on page load and stays on the page still the user click on the close. Reappears on mouseover. </li>
<li><i class="fa fa-angle-right"></i> Standard ad size depending on photo size. </li>
<li><i class="fa fa-angle-right"></i> Great for 728 x 90, 468 x 60 ads. </li>
<li><i class="fa fa-angle-right"></i> Shows a max of 3 ads on photos per user per day. </li>
<li><i class="fa fa-angle-right"></i> Users look carefully at the photos so CTR is high. </li>
<li><i class="fa fa-angle-right"></i> Could show the ad at the bottom of the photo or in the middle of the photo.M</li>
</ul>
<h4 class="statich4">Standard Specifications</h4>
<div class="Advertise-sec">
<ul class="table-cover">
<li class="stand-col">Ad Dimensions:</li>
<li>728 x 90, 468 x 60</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Type:</li>
<li>Images and Flash</li>
</ul>
<ul class="table-cover">
<li class="stand-col">Max File size:</li>
<li>30KB</li>
</ul>
</div>

        </div>
         </div>
        </div>