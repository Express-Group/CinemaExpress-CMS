
<div class="ad300">
<img class="lazy"  data-src="<?php echo $image_path_inwd; ?>images/ad300.jpg">
</div>
