<div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
             <h4 class="form-title">About Us</h4>
             <figure class="footer-img"><img src="<?php echo base_url();?>images/FrontEnd/images/TNIE-office.png"  data-src="<?php echo base_url();?>images/FrontEnd/images/TNIE-office.png"></figure>
          <div class="privacy-policy">
         <p>The New Indian Express is the oldest English daily of an undisputed credibility for the last 80 years.</p>

<p>New Indian Express is arguably the flagship publication incorporating national and international themes and sections on developmental issues, society, politics, literature, arts, cinema, travel, lifestyle, sports, business, finance, new-age living, self-development and entertainment. </p>

<p>The readers of the newspaper spread all across the world with a very high NRI traffic to the website.</p>
 

<p>The publication boasts of a dynamic and discerning profile of informed readers who are constantly exploring new possibilities to make their lives better.</p>

<p>The company was promoted by Express Publications (Madurai) Limited which is the flagship Company of the Group.</p>

<p>Express Publications (Madurai) Limited publishes the prestigious English language Newspaper, The New Indian Express from 25 centers in Tamilnadu, Karnataka, Andhra Pradesh, Kerala and Odisha.</p>

<p>It also publishes Sunday Standard from New Delhi. Express Publications (Madurai) Limited also publishes Tamil daily Dinamani , Cinema Express (Tamil), Malayalam Varika (Malayalam) and Sakhi (Kannada).</p>

<p>The company is owned and managed by Shri Manoj Kumar Sonthalia. The Editorial Director of the group is Mr Prabhu Chawla.</p>


          </div>
           
         </div>
        </div>