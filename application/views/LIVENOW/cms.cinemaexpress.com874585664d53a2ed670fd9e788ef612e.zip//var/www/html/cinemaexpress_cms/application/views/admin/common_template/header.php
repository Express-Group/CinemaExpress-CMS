<section class="section-header">
<header class="HeaderContainer container">

	<?php echo $view_templ; ?>

</header>
</section>