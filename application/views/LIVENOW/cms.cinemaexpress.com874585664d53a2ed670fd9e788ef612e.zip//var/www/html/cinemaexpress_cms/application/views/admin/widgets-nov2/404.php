<?php
$widget_bg_color 		= $content['widget_bg_color'];
$widget_instance_id	 	= $content['widget_values']['data-widgetinstanceid'];
$view_mode              = $content['mode'];
?>
<div class="row">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="no-page">
<h4>Oops!</h4>
<p>Looks like you are looking for a page that doesn't exist or has been moved.</p>

<p>Please check the url to see if there are any mistakes or use the search box below to find the content you are looking for.</p>

<p>If you still have difficulty finding what you need, please <a href="<?php echo base_url();?>">click here</a> to go to the homepage or here to <a href="<?php echo base_url();?>contact-us">contact us</a>.</p>

<p>Thanks for visiting our site. Do return later.</p>
</div>
  </div>
</div>
