<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="SundayLead">
<div class="SundayLeadLeft">
<a href="#"><img data-src="images/palace77.jpg" class="ImageBorder"></a>
<h4 class="subtopic Bold">
<a href="#">Choking Delhi Needs Plastic Surgery</a>
</h4>
<p>The 2,51,850 tonnes of plastic waste generated every year cause grave diseases, choke drains and the yamuna, poison groundwater, destroy green areas tonnes of plastic waste generated every year cause grave diseases, choke drains</p>
</div>
<div class="SundayLeadMiddle">
<a href="#"><img data-src="images/shradha77.jpg" class="ImageBorder"></a>
<h4 class="subtopic">
<a href="#">The yamuna, poison ground water destroy</a>
</h4>
<p>The 2,51,850 tonnes of plastic waste generated every year cause grave diseases choke drains and the yamuna, Poison ground water, destroy green areas, and endanger animals and people. the civic authorities are helpless.</p>
</div>
<div class="SundayLeadRight">
<a href="#"><img data-src="images/mountain77.jpg" class="ImageBorder"></a>
<p>The civic authorities  often helpless the civic</p>
<a href="#"><img data-src="images/norway77.jpg" class="ImageBorder"></a>
<p>The yamuna, Poison ground water, destroy green areas, and endanger animals.</p>
</div>
</div>
</div>
</div>