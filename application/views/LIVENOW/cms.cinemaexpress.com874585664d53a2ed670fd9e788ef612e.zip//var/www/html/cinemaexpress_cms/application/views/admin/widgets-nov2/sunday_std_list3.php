<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="SundayThird">
<div class="SundayThirdLeft">
<a href="#"><img data-src="images/norway77.jpg" class="ImageBorder"></a>
<h4 class="subtopic">
<a href="#">Rajpath Prepares for Posture Perfect </a>
</h4>
<p>The yamuna, Poison ground water, destroy green areas, and endanger animals.</p>
</div>
<div class="SundayThirdRight">
<div class="SundayThirdTop">
<div>
<a href="#"><img data-src="images/norway77.jpg" class="ImageBorder"></a>
</div>
<div>
<h4 class="subtopic">
<a href="#">Rajpath Prepares for Posture Perfect </a>
</h4>
<p>The yamuna, Poison ground water, destroy green areas, and endanger animals.</p>
</div>
</div>
<div class="SundayThirdTop">
<div>
<a href="#"><img data-src="images/norway77.jpg" class="ImageBorder"></a>
</div>
<div>
<h4 class="subtopic">
<a href="#">Rajpath Prepares for Posture Perfect this Summer </a>
</h4>
<p>The yamuna, Poison ground water, destroy green areas, and endanger animals.</p>
</div>
</div>
</div>
</div>
</div>
</div>