<div class="FooterWrapper Overflow FrontPageManager-footer">
<div class="Container">
 <p class="FloatLeft">Copyright © 2015-2016 <a href="javascript:void()">Express Network Pvt Ltd.</a> All rights reserved.</p>
 <div class="FloatRight FooterLogo">
<p>Powered By: <a>ENPL.</a>  Version 1.0</p>
 </div>
 </div>
</div> 
</body>
</html>
