<?php
$widget_instance_id =  $content['widget_values']['data-widgetinstanceid'];
?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="facebook_timeline" id="facebook_<?php echo $widget_instance_id;?>">
  

<a class="twitter-timeline" data-height="400" href="https://twitter.com/XpressCinema">
Tweets by @XpressCinema
</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
</div></div>
</div>
